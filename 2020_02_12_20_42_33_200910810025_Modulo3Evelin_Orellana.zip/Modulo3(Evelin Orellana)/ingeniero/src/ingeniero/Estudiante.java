/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ingeniero;

/**
 *
 * @author Felix
 */
public class Estudiante {
     private String identidad;
    private String nombre;
    private String apellido;
    private int edad;
    private String sexo;
    
    public Estudiante(){    
    
    }
    public Estudiante(String identidad, String nombre,String apellido, int edad,String sexo ){    
     this.setIdentidad(identidad);
     this.setNombre(nombre);
     this.setApellido(apellido);
     this.setEdad(edad);
     this.setSexo(sexo);
    }
    
    public String getIdentidad(){
        return identidad;
    }
    public String getNombre(){
        return nombre;
    }
    public String getApellido(){
        return apellido;
    }
    public int getEdad(){
        return edad;
    }
    public String getSexo(){
        return sexo;
    }
    public void setIdentidad(String identidad){
        this.identidad=identidad; 
    }
    public void setNombre(String nombre){
        this.nombre=nombre; 
    }
    public void setApellido(String apellido){
        this.apellido=apellido; 
    }
    public void setEdad(int edad){
        this.edad=edad;
    }
    public void setSexo(String sexo){
        this.sexo=sexo;
    }
}
