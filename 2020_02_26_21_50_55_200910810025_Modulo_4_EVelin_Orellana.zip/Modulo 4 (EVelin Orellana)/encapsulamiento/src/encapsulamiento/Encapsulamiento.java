/*
 1. Crear una clase de nombre Ciudadano en el que se declaren y protejan sus métodos 
y propiedades utilizando encapsulamiento, desde la clase que contiene el método principal, 
establecer y obtener su edad, nombre y años de experiencia (Métodos set y get).
 */
package encapsulamiento;

import stud.Ciudadano;

/**
 *
 * @author Evelin
 */
public class Encapsulamiento {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Ciudadano ciudadano=new Ciudadano("Felix Diaz",2);
        ciudadano.imprimirnombre();
        ciudadano.imprimirexperiencia();
        ciudadano.estableceredad(32);
        System.out.println(ciudadano.obteneredad());
    }
    
}
