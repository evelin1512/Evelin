/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstraccion.abs;

/**
 *
 * @author Evelin
 */
public class Honduras extends pais {

    public boolean getpais;

    @Override
    public String getpais() {
        return "Honduras";
    }

    @Override
    public String getpresidente() {
        return "Juan Orlando Hernández";
    }
    
}
