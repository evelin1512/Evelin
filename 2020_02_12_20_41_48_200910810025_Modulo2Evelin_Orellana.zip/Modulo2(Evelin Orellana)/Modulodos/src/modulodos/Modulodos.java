/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modulodos;

/**
 *
 * @author Evelin Orellana
 */
public class Modulodos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Recurso recurso=new Recurso();
        recurso.mensaje();
        recurso.variable(89);
        recurso.division(10,5);
        recurso.numeros(8);          
 }
    public static class Recurso{
        public void mensaje(){
            System.out.println("Estoy aprendiendo, pero sere el mejor programador");
        }
        public void variable(int nota){
            if (nota>=70){
                System.out.println(nota + " Aprobado");
            }else{
                System.out.println(nota + "Reprobado");
            }    
        }
        public void division(int n1,int n2){
            int divi;
            if (n1!=0){
              divi=n1/n2;
              System.out.println(divi);
            }else{
               System.out.println("no esta definida"); 
            }    
            }
        public void numeros(int x){
          for(int i=1;i<=x;i=i+1){
             System.out.print(i+" ");
          }   
            
        }
    }// TODO code application logic here
    }
    
