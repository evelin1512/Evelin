/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ingeniero;

/**
 *
 * @author Felix
 */
public class Ingeniero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Estudiante estudiante =new Estudiante();
        estudiante.setIdentidad("0506198918809");
        estudiante.setNombre("Evelin");
        estudiante.setApellido("Orellana");
        estudiante.setEdad(25);
        estudiante.setSexo("Femenino: ");
        System.out.println("Identidad: "+estudiante.getIdentidad());
        System.out.println("Nombre: "+estudiante.getNombre());
        System.out.println("Apellido: "+estudiante.getApellido());
        System.out.println("Edad: "+estudiante.getApellido());
        System.out.println("Sexo: "+estudiante.getSexo());
    }
    
}
