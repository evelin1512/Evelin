/*
 1. Crear una clase de nombre Ciudadano en el que se declaren y protejan sus métodos 
y propiedades utilizando encapsulamiento, desde la clase que contiene el método principal, 
establecer y obtener su edad, nombre y años de experiencia (Métodos set y get).
 */
package stud;

/**
 *
 * @author Evelin
 */
public class Ciudadano {
    public String nombre;
    private int experiencia;
    private int edad;
    
    public Ciudadano(String nombre,int experiencia){
        this.nombre=nombre;
        this.experiencia= experiencia;
    }
    public void imprimirexperiencia(){
        System.out.println(experiencia);
    }
    public void imprimirnombre(){
       System.out.println(nombre); 
    } 
    public void estableceredad(int _edad){
     this.edad=_edad;   
    }
    public int obteneredad(){
     return edad;   
    }
    
}
