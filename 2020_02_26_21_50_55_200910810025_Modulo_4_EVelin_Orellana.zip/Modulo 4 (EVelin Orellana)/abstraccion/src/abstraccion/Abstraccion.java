/*
 1. Cree una clase abstracta llamada Pais, que contenga los siguientes métodos 
abstractos: getPais, getPresidente

2. Declare 3 clases con diferentes paises extendiendo de la clase Pais, 
por ejemplo: Honduras, CostaRica, ElSalvador, etc. 

En la clase que contiene el método principal (main), imprimir el nombre de los países 
y su presidente.

 */
package abstraccion;

import abstraccion.abs.CostaRica;
import abstraccion.abs.ElSalvador;
import abstraccion.abs.Honduras;

/**
 *
 * @author Evelin
 */
public class Abstraccion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Honduras PH=new Honduras ();
        ElSalvador PES=new ElSalvador ();
        CostaRica PCR=new CostaRica ();
        System.out.println(PH.getpais());
       System.out.println(PH.getpresidente());
        System.out.println(PES.getpais());
       System.out.println(PES.getpresidente());
        System.out.println(PCR.getpais());
       System.out.println(PCR.getpresidente());
        
        
        
        
    }
    
}
