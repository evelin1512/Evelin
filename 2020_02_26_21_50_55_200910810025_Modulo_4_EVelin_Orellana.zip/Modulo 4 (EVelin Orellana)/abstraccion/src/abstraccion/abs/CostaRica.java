/*
 * 1. Cree una clase abstracta llamada Pais, que contenga los siguientes métodos 
abstractos: getPais, getPresidente

2. Declare 3 clases con diferentes paises extendiendo de la clase Pais, 
por ejemplo: Honduras, CostaRica, ElSalvador, etc. 

En la clase que contiene el método principal (main), imprimir el nombre de los países 
y su presidente.
 */
package abstraccion.abs;

/**
 *
 * @author Evelin
 */
public class CostaRica extends pais {
         @Override
    public String getpais() {
        return "Costa Rica";
    }

    @Override
    public String getpresidente() {
        return "Carlos Alvaro Quesada";
    }
}
